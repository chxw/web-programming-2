from django.apps import AppConfig


class NbastatsConfig(AppConfig):
    name = 'nbastats'
